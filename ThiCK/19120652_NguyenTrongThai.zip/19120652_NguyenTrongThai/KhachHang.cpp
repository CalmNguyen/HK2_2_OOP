#include"KhachHang.h"
bool KhachHang::getter() {
	return loai;
}
void KhachHang::setter(bool kt) {
	loai = kt;
}
float KhachHang::getSL() {
	return SoLuong;
}
string KhachHang::getThang() {
	string t;
	for (int i = 0; i < NgayXHD.size(); i++) {
		if (NgayXHD[i] == '/') {
			t += NgayXHD[i + 1];
			if (NgayXHD[i + 2] != '/')
				t += NgayXHD[i + 2];
			return t;
		}
	}
}
string KhachHang::getNam() {
	string n;
	int count = 0;
	for (int i = 0; i < NgayXHD.size(); i++)
	{
		if (count == 2) {
			n += NgayXHD[i];
		}
		if (NgayXHD[i] == '/')
			count++;
	}
	return n;
}
int KhachHang::SoSanhMaKH(KhachHang* x) {
	if (x->MaKH < MaKH)
		return -1;
	if (MaKH == x->MaKH)
		return 0;
	return 1;
}
void KhachHang::Nhap() {
	cout << "\tNhap khach hang\n";
	cout << "Nhap ma khach hang:";
	cin >> MaKH;
	cout << "Nhap ho ten:";
	cin.ignore();
	getline(cin, HoTen);
	cout << "Nhap ngay xuat hoa don(dd/mm/yy):";
	cin >> NgayXHD;
	cout << "Nhap so luong(KW):";
	cin >> SoLuong;
	cout << "Nhap don gia:";
	cin >> DonGia;
}
void KhachHang::Xuat() {
	cout << "\tXuat khach hang\n";
	cout << "Ma khach hang:" << MaKH << endl;
	cout << "Ho ten:" << HoTen << endl;
	cout << "Ngay xuat hoa don:" << NgayXHD << endl;
	cout << "SoLuong:" << SoLuong << endl;
	cout << "Don gia:" << DonGia << endl;
}