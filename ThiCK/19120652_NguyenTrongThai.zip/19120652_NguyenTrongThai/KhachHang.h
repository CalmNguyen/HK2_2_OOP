#pragma once
#include<iostream>
using namespace std;
#include<string>
class KhachHang {
protected:
	string MaKH;
	string HoTen;
	string NgayXHD;//  dd//mm//yy
	float SoLuong;
	int DonGia;
	bool loai;
public:
	KhachHang() {
	}
	~KhachHang() {}
	virtual void Nhap();
	virtual void Xuat();
	virtual float TinhTien() {
		return 0;
	}
	bool getter();
	void setter(bool kt);
	float getSL();
	string getThang();
	string getNam();
	int SoSanhMaKH(KhachHang* x);
};