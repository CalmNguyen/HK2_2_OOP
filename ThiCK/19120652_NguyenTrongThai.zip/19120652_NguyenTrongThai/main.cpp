#include"QLKhachHang.h"


int main() {
	QLKhachHang a;
	a.Nhap_DS();
	cout << endl << endl << endl;
	KhachHang* ss = new KhachHangVN;
	cout << "\t\tNhap khach hang VN muon them\n";
	ss->Nhap();
	cout << "\n\n Tinh tong tien cua khach hang VN vua nhap:" << ss->TinhTien() << endl;

	a.ThemKH(ss);
	cout << endl;
	a.Xuat_DS();
	cout << endl;
	cout << "\t\tDanh sach khach hang thang 3 nam 2021\n\n";
	a.XuatHD_ThangNam("3", "2021");
	cout << endl << endl;
	a.Xuat_DS();
	cout << "\n\nTong so luong(KW) khach hang nuoc ngoai:" << a.TongSL_KHNN() << endl;
	cout<<"\n\nTong so luong(KW) khach hang trong nuoc:"<< a.TongSL_KHVN() << endl;
	delete ss;
	system("pause");
	return 0;
}
