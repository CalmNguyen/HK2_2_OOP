#pragma once
#include"KhachHang.h"
class KhachHangNN :public KhachHang {
private:
	string QuocTich;
public:
	void Nhap();
	void Xuat();
	float TinhTien();
};