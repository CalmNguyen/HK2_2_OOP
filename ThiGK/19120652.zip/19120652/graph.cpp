#include<iostream>
using namespace std;
class Graph {
private:
	int vertec;
	bool adj[100][100];
public:
	Graph()
	{
		vertec = 0;
		for (int i = 0; i < 100; i++)
			for (int j = 0; j < 100; j++)
				adj[i][j] = 0;
	}
	~Graph() {}
	void addEdge(int s, int e);
	void remove(int s, int e);
	void print();
};
void Graph::addEdge(int s, int e) {
	if (s == e)
		return;
	for (int i = 0; i < 100; i++)
		for (int j = 0; j < 100; j++)
		{
			if (i == s && j == e)
				adj[i][j] = 1;
			if (j == s && i == e)
				adj[i][j] = 1;
		}
}
void Graph::remove(int s, int e) 
{
	for (int i = 0; i < 100; i++)
	{
		adj[s][i] = 0;
		adj[e][i] = 0;
		adj[i][s] = 0;
		adj[i][e] = 0;
	}
}
void Graph::print() 
{
	for (int i = 1; i < 100; i++) {
		for (int j = 1; j < 100; j++) {
			cout << adj[i][j] << " ";
		}
		cout << endl;
	}

}