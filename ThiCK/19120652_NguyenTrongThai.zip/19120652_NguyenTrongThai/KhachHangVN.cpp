#include"KhachHangVN.h"
void KhachHangVN::Nhap() {
	KhachHang::Nhap();
	cout << "1.Sinh hoat\n2.Kinh doanh\n3.SanXuat\nNhap loai doi tuong:";
	cin >> DTKH;
	if (DTKH == 1)
		DinhMuc = 200;
	else if (DTKH == 2)
		DinhMuc = 300;
	else if (DTKH == 3)
		DinhMuc = 500;
	else;
}
void KhachHangVN::Xuat() {
	KhachHang::Xuat();
	cout << "Loai doi tuong:" << DTKH << endl;
	cout << "Dinh muc:" << DinhMuc << endl;
}
float KhachHangVN::TinhTien() {
	if (SoLuong <= DinhMuc)
		return SoLuong * DonGia;
	return DinhMuc * DonGia + (SoLuong - float(DinhMuc)) * 2.5 * DonGia;
}