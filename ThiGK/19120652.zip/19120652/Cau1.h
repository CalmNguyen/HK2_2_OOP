#pragma once
#include<iostream>
using namespace std;
struct Node {
	int data;
	Node* pNext;
};
class queue {
private:
	Node* pHead;
	Node* pTail;
public:
	// Constructors
	queue();
	// Kiem tra hang doi rong
	bool isEmpty();
	// Them 1 phan tu vao hang doi
	void enqueue(int x);
	// Lay phan tu dau tien
	Node* front();
	// Xoa 1 phan tu
	void dequeue();
	void print(Node* p);
	void deleteAll() {
		while (pHead != nullptr)
			dequeue();
	}

};