#include<iostream>
using namespace std;
#include"Cau1.h"
int main() {
	int size;
	cout << "Nhap size:";
	cin >> size;
	int choose;
	int Mark[100];
	for (int i = 1; i <= size; i++)
		Mark[i] = 0;
	do {
		cout << "Nhap vi tri bat dau:";
		cin >> choose;
	} 	while (choose<1 || choose>size);
	queue X;
	int y;
	X.enqueue(choose);
	int check = 0;
	while (X.isEmpty()!=true) {
		check = 0;
		y = X.front()->data;
		Mark[y] = 1;//da xet y
		cout << y;
		X.dequeue();
		for (int i = 1; i <= size; i++)
		{
			if (Mark[i] == 0)
			{
				check = 1;
				choose = i;
				X.enqueue(choose);
			}
			if (check != 1)
				break;
		}

	}
	X.deleteAll();
	system("pause");
	return 0;
}