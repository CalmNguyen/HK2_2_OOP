#pragma once
#include"KhachHang.h"
class KhachHangVN :public KhachHang {
private:
	int DTKH; // 1.Sinh hoat  2.Kinh doanh   3.San xuat
	int DinhMuc;
public:
	void Nhap();
	void Xuat();
	float TinhTien();
};