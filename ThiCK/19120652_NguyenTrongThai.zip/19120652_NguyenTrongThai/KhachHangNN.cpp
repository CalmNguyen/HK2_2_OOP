#include"KhachHangNN.h"

void KhachHangNN::Nhap() {
	KhachHang::Nhap();
	cout << "Nhap quoc tinh:";
	cin.ignore();
	getline(cin, QuocTich);
}
void KhachHangNN::Xuat() {
	KhachHang::Xuat();
	cout << "Quoc tich:" << QuocTich << endl;
}
float KhachHangNN::TinhTien() {
	return SoLuong * DonGia;
}