#include"Cau1.h"
queue::queue() {
	pHead = pTail = nullptr;
}
bool queue:: isEmpty() {
	if (pHead == nullptr && pTail == nullptr)
		return true;
	return false;
}
void queue::enqueue(int x) {
	Node* new_x = new Node{ x,nullptr };
	if (isEmpty())
	{
		pHead = pTail = new_x;
		pHead->pNext = nullptr;
		pTail->pNext = nullptr;
	}
	else 
	{
		pTail->pNext = new_x;
		pTail = new_x;
	}
}
//Phan tu dau tien
Node* queue::front() {
	return pHead;
}
void queue::dequeue() {
	if (pHead == nullptr)
		return;
	if (pHead == pTail)
	{
		delete pHead;
		pHead = pTail = nullptr;
		return;
	}
	Node* temp = pHead;
	Node*temp1 = temp->pNext;
	delete temp;
	temp = nullptr;
	pHead=temp1;
}
void queue::print(Node* p) {
	p = pHead;
	if (p == nullptr)
		return;
	while (p != nullptr) {
		cout << p->data << "  ";
		p = p->pNext;
	}
}
int main() {
	queue a;
	a.enqueue(3);
	a.dequeue();
	a.enqueue(123);
	cout << a.front()->data << endl;
	a.enqueue(2);
	a.enqueue(1);
	a.print(a.front());
	a.deleteAll();
}